<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style type="text/css">
	footer
	{
		height: 70px;
		width: 1361px;
		background-color: #00000;
	}
		.fa
		{
			margin: 0px 5px;
			padding: 5px;
			font-size: 20px;
			width: 30px;
			height: 150px;
			text-align: center;
			text-decoration: none;
			border-radius: 50%;
		}
		.fa:hover
		{
			opacity: .7;
		}

	</style>

</head>
<body>
<footer style="background-color: black; ">
	<br>
	<br>
	<p style="color: #00ff00;text-align: center;">
		<br>
		<h5>Email:&nbsp Online.manybook@gmail.com <br><br>
	</p>
</footer>
</body>
</html>